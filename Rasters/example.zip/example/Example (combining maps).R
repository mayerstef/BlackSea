library(readr)
### Projection definition
proj84 <- CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs +towgs84=0,0,0") 
sf::sf_use_s2(F) #global option for using the S2 geometry library to FALSE

Bioreg<-st_read("./Data/GIS/10bioregions_blacksea.shp") #10 features, see script "BlackSea_Bioregions" for shapefile creation
Bioreg <- st_transform(Bioreg, proj84)
Bioreg_bf <- st_buffer(Bioreg, dist = .1)
Bioregion_fished <- st_read("Data/GIS/fishedEEZ_blacksea.shp")
Bioregion_fished<-st_transform(Bioregion_fished, proj84)
plot(Bioregion_fished)

bathy <- raster("./Data/GIS/gebco_blacksea.asc") 

coast <- st_read("./Data/GIS/coastline_blacksea.shp") #only used for maps, not so important

coast_bf<-Bioreg_bf  %>%
  summarise()
coast_bf<-st_transform(coast_bf, proj84)

xmin <- 26.223404293 #lon
xmax <- 41.923404293 #lon
ymin <- 39.879949463 #lat
ymax <- 47.379949463 #lat


new_extent <- raster::extent(xmin, xmax, ymin, ymax)
FAO <- raster("./Rasters/example/Acipenser_ruthenus_FAO.asc") 
#%>% crop(new_extent) %>% mask(coast_bf, updatevalue=0)
#plot(FAO)
IUCN <- raster("./Rasters/example/Acipenser_ruthenus_IUCN.asc")
#%>%   crop(new_extent) %>% mask(coast_bf, updatevalue=0)
#plot(IUCN)
fishery <- raster("./Rasters/example/Acipenser_ruthenus_fishery.asc")
#%>%  crop(new_extent) %>%  mask(coast_bf, updatevalue=0)
#plot(fishery)
occurence <- raster("./Rasters/example/Acipenser_ruthenus_occurences.asc")
#%>%  crop(new_extent) %>%  mask(coast_bf, updatevalue=0)
#plot(occurence)
res(occurence)


# Mosaic the first two raster files
mosaic1 <- mosaic(FAO, IUCN, fun=max)
mosaic2 <- mosaic(mosaic1, fishery, fun=max)
res(occurence)<-res(mosaic2)
mosaic_final <- mosaic(mosaic2, occurence, fun=max)
plot(mosaic_final)

Min_x<- 26.223404293 #lon
Max_x <- 41.923404293 #lon
Min_y <- 39.879949463 #lat
Max_y  <- 47.379949463 #lat


countries <- ne_countries(scale = "medium", returnclass = "sf")
countries <- st_as_sf(countries, crs = proj84)
png(paste0("./Rasters/example/maps/fishery.png"), width = 2000, height = 1400, units = "px", pointsize = 10, res = 300)
plot(rnorm(1000), col = "transparent", type = "n", axes = FALSE, 
     xlab = "", ylab = "", 
     xlim = c(Min_x, Max_x), ylim = c(Min_y, Max_y), #main = as.expression(bquote(paste("Species Distribution of ", italic(.(Species_name))))), 
     mar = c(5, 5, 4, 2) + 0.1)
image(fishery, col = c("transparent",   "#ffd60a"), add = TRUE)
plot(Bioregion_fished,  col = "transparent", add = TRUE, lwd = 0.1)
plot(countries, col = "gray80", add = TRUE, lwd=0.1)

addnortharrow(
  pos = "topright",
  padin = c(0.15, 0.15),
  scale = 0.5,
  lwd = 1,
  border = "black",
  cols = c("white", "black"),
  text.col = "black"
  )
  addscalebar(
  plotunit = NULL,
  plotepsg = NULL,
  widthhint = 0.15,
  unitcategory = "metric",
  htin = 0.1,
  padin = c(0.15, 0.15),
    style = "bar",
  bar.cols = c("black", "white"),
    lwd = 1,
    linecol = "black",
    tick.cex = 0.7,
    labelpadin = 0.08,
    label.cex = 0.8,
    label.col = "black",
    pos = "bottomright"
  )
  dev.off()


png(paste0("./Rasters/example/maps/IUCN.png"), width = 2000, height = 1400, units = "px", pointsize = 10, res = 300)
plot(rnorm(1000), col = "transparent", type = "n", axes = FALSE, 
     xlab = "", ylab = "", 
     xlim = c(Min_x, Max_x), ylim = c(Min_y, Max_y), #main = as.expression(bquote(paste("Species Distribution of ", italic(.(Species_name))))), 
     mar = c(5, 5, 4, 2) + 0.1)
image(IUCN, col = c("transparent", "#ae2012ff"), add = TRUE)
plot(Bioregion_fished,  col = "transparent", add = TRUE, lwd = 0.1)
plot(countries, col = "gray80", add = TRUE, lwd=0.1)

addnortharrow(
  pos = "topright",
  padin = c(0.15, 0.15),
  scale = 0.5,
  lwd = 1,
  border = "black",
  cols = c("white", "black"),
  text.col = "black"
)
addscalebar(
  plotunit = NULL,
  plotepsg = NULL,
  widthhint = 0.15,
  unitcategory = "metric",
  htin = 0.1,
  padin = c(0.15, 0.15),
  style = "bar",
  bar.cols = c("black", "white"),
  lwd = 1,
  linecol = "black",
  tick.cex = 0.7,
  labelpadin = 0.08,
  label.cex = 0.8,
  label.col = "black",
  pos = "bottomright"
)
dev.off()


png(paste0("./Rasters/example/maps/FAO.png"), width = 2000, height = 1400, units = "px", pointsize = 10, res = 300)
plot(rnorm(1000), col = "transparent", type = "n", axes = FALSE, 
     xlab = "", ylab = "", 
     xlim = c(Min_x, Max_x), ylim = c(Min_y, Max_y), #main = as.expression(bquote(paste("Species Distribution of ", italic(.(Species_name))))), 
     mar = c(5, 5, 4, 2) + 0.1)
image(FAO, col = c("transparent", "#0a9396"), add = TRUE)
plot(Bioregion_fished,  col = "transparent", add = TRUE, lwd = 0.1)
plot(countries, col = "gray80", add = TRUE, lwd=0.1)

addnortharrow(
  pos = "topright",
  padin = c(0.15, 0.15),
  scale = 0.5,
  lwd = 1,
  border = "black",
  cols = c("white", "black"),
  text.col = "black"
)
addscalebar(
  plotunit = NULL,
  plotepsg = NULL,
  widthhint = 0.15,
  unitcategory = "metric",
  htin = 0.1,
  padin = c(0.15, 0.15),
  style = "bar",
  bar.cols = c("black", "white"),
  lwd = 1,
  linecol = "black",
  tick.cex = 0.7,
  labelpadin = 0.08,
  label.cex = 0.8,
  label.col = "black",
  pos = "bottomright"
)
dev.off()

Occ<- read_csv("Rasters/example/Acipenser_ruthenus.csv")
Occ <- Occ[, c("longitude", "latitude", "species")]

png(paste0("./Rasters/example/maps/occurence4.png"), width = 2000, height = 1400, units = "px", pointsize = 10, res = 300)
plot(rnorm(1000), col = "transparent", type = "n", axes = FALSE, 
     xlab = "", ylab = "", 
     xlim = c(Min_x, Max_x), ylim = c(Min_y, Max_y), #main = as.expression(bquote(paste("Species Distribution of ", italic(.(Species_name))))), 
     mar = c(5, 5, 4, 2) + 0.1)
image(occurence, col = c("transparent", "#90be6d"), add = TRUE)
plot(Bioregion_fished,  col = "transparent", add = TRUE, lwd = 0.1)
plot(countries, col = "gray80", add = TRUE, lwd=0.1)
points(Occ[, c(1, 2)], pch = 20, col = "#2a4d14", cex = 1.2)
points(Occ[, c(1, 2)], pch = 20, col = "#f1f1de", cex = 0.8)

addnortharrow(
  pos = "topright",
  padin = c(0.15, 0.15),
  scale = 0.5,
  lwd = 1,
  border = "black",
  cols = c("white", "black"),
  text.col = "black"
)
addscalebar(
  plotunit = NULL,
  plotepsg = NULL,
  widthhint = 0.15,
  unitcategory = "metric",
  htin = 0.1,
  padin = c(0.15, 0.15),
  style = "bar",
  bar.cols = c("black", "white"),
  lwd = 1,
  linecol = "black",
  tick.cex = 0.7,
  labelpadin = 0.08,
  label.cex = 0.8,
  label.col = "black",
  pos = "bottomright"
)
dev.off()

###
#


png(paste0("./Rasters/example/maps/combined.png"), width = 2000, height = 1400, units = "px", pointsize = 10, res = 300)
plot(rnorm(1000), col = "transparent", type = "n", axes = FALSE, 
     xlab = "", ylab = "", 
     xlim = c(Min_x, Max_x), ylim = c(Min_y, Max_y), #main = as.expression(bquote(paste("Species Distribution of ", italic(.(Species_name))))), 
     mar = c(5, 5, 4, 2) + 0.1)
image(mosaic_final, col = c("transparent", "#ebc97d"), add = TRUE)
plot(Bioregion_fished,  col = "transparent", add = TRUE, lwd = 0.1)
plot(countries, col = "gray80", add = TRUE, lwd=0.1)

addnortharrow(
  pos = "topright",
  padin = c(0.15, 0.15),
  scale = 0.5,
  lwd = 1,
  border = "black",
  cols = c("white", "black"),
  text.col = "black"
)
addscalebar(
  plotunit = NULL,
  plotepsg = NULL,
  widthhint = 0.15,
  unitcategory = "metric",
  htin = 0.1,
  padin = c(0.15, 0.15),
  style = "bar",
  bar.cols = c("black", "white"),
  lwd = 1,
  linecol = "black",
  tick.cex = 0.7,
  labelpadin = 0.08,
  label.cex = 0.8,
  label.col = "black",
  pos = "bottomright"
)
dev.off()

